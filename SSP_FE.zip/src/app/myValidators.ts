import {AbstractControl, ValidationErrors} from '@angular/forms';

export class MyValidators{

    static shouldBeUnique(control: AbstractControl) : Promise<ValidationErrors | null>    {
        
        return new Promise((resolve,reject) => {
            setTimeout( () => {
                alert('dvdfv: '+control.value);
                if(control.value=='boss')
                    resolve({ shouldBeUnique:true });
                else
                    resolve(null);
            },10000);
        });
    }

    static cannotContainSpace(control: AbstractControl) : ValidationErrors | null{
        if(control.value.indexOf(' ')>=0)
            return {cannotContainSpace:true};

        return null;
    }
}