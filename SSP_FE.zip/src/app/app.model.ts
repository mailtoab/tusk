export class Response {
  Status: string;
  ClarityDetails: ClarityDetail[];
}


export class ClarityDetail {
  ClarityID: string;
  LinesAdded: Int32Array;
  LinesDeleted: Int32Array;
  ApplicationDetails : ApplicationDetail[] 
}

export class ApplicationDetail {
  ApplicationName: string;
  LinesAdded: Int32Array;
  LinesDeleted: Int32Array;
  JIRADetails : JIRADetail[] 
}

export class JIRADetail {
  JIRA_ID: string;
  LinesAdded: Int32Array;
  LinesDeleted: Int32Array;
  DeveloperName: string;
  DeveloperVZID: string;
}


