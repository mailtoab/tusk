import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class AppService {

  constructor(private http: Http) {}

  private url = 'http://localhost:8089/api/toDos';

  public getAllTasks() {
    //return this.http.get( this.url + '/toDo/allToDos');
    return this.http.get( './assets/system.json');
  }

  public createTask(task) {
    return this.http.post(this.url + '/create', task);
  }

  public getToDoByTask(task) {
    return this.http.post(this.url + '/toDo', task);
  }

}