import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Http } from '@angular/http';
import { AppService } from './app.service';
import {  Response, ClarityDetail, ApplicationDetail, JIRADetail } from './app.model';
import { MyValidators } from './myValidators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'RELEASE STATUS';  

  form = new FormGroup({
    task: new FormControl('',[
      Validators.required
      ])
  });//Syntax: FormGroup([Key as string]: AbstractControl)

  Response: Response;
  globalResponse: Response;

  constructor(private appService: AppService) {

  }

  ngOnInit() {
    this.appService.getAllTasks()
      .subscribe( data => {
        this.Response = data.json();
        this.globalResponse = data.json();
      });
  };

  getClarity(clarityID){
    //alert(clarityID.value);
    for(let clarityDetail of this.globalResponse.ClarityDetails){
      //alert('Inside for');
      if(clarityDetail.ClarityID==clarityID.value){
        //alert('Inside If'); 
        let clarityArray: ClarityDetail[] = [clarityDetail];
        this.Response.ClarityDetails=clarityArray;
        break;
      }      
   }

  }

  /*insertTask(input){
    let task = { task: input.value, status:'Pending' };
    this.appService.createTask(task)
      .subscribe(response =>{
        this.allTask=response.json();
      });
  }  

  updateStatus(t,pid){
  	let task = { id: pid, task: t,status:'Completed' };
    this.appService.createTask(task)
      .subscribe(response =>{
        this.allTask=response.json();
      });
  }  

  reopen(t,pid){
    let task = { id: pid, task: t,status:'Pending' };
    this.appService.createTask(task)
      .subscribe(response =>{
        this.allTask=response.json();
      });
  } */

  get task(){
  	return this.form.get('task');
  }

}
 